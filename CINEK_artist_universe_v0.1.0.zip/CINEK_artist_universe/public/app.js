async function loadCatalog(){
  try{
    const [songsRes, socialsRes]=await Promise.all([fetch('/api/songs.json'),fetch('/api/socials.json')]);
    const songs=await songsRes.json(), socials=await socialsRes.json();
    const songRoot=document.querySelector('#songs');
    songRoot.innerHTML=songs.map((s,i)=>`<article class="song-card"><div><span class="num">${String(i+1).padStart(2,'0')} / TRACK</span><h3>${escapeHtml(s.title)}</h3><a href="${s.links.official_hub}" target="_blank" rel="noreferrer">Find official listening links ↗</a></div></article>`).join('');
    document.querySelector('#socials').innerHTML=socials.map(s=>`<span class="social-pill">${escapeHtml(s.name)} · ${s.url?'verified link':'direct URL pending verification'}</span>`).join('');
  }catch(e){document.querySelector('#songs').textContent='Catalogue unavailable.'}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
loadCatalog();
