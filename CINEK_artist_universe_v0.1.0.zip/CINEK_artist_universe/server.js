const http = require('http');
const fs = require('fs');
const path = require('path');
const catalog = require('./public/api/index.json');
const root = path.join(__dirname, 'public');
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.svg':'image/svg+xml'};
function send(res, status, data, type='application/json; charset=utf-8'){res.writeHead(status, {'Content-Type':type,'Access-Control-Allow-Origin':'*'});res.end(Buffer.isBuffer(data)?data:(typeof data==='string'?data:JSON.stringify(data)));}
function tool(name,description,inputSchema){return {name,description,inputSchema};}
const tools=[
 tool('get_artist','Get the public Cinek artist project record.',{type:'object',properties:{},additionalProperties:false}),
 tool('list_songs','List known Cinek song entries.',{type:'object',properties:{},additionalProperties:false}),
 tool('list_links','List verified and pending social links.',{type:'object',properties:{},additionalProperties:false}),
 tool('list_wiki','List creative archive/wiki topics.',{type:'object',properties:{},additionalProperties:false}),
 tool('search_catalog','Search song titles and wiki topics.',{type:'object',properties:{query:{type:'string'}},required:['query'],additionalProperties:false})
];
function rpcResult(id,result){return {jsonrpc:'2.0',id,result};}
const server=http.createServer((req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET' && url.pathname==='/health') return send(res,200,{ok:true,name:'cinek-artist-universe'});
 if(req.method==='GET' && url.pathname==='/mcp') return send(res,200,{name:'cinek-artist-universe-mcp',transport:'POST JSON-RPC',tools:tools.map(t=>t.name)});
 if(req.method==='POST' && url.pathname==='/mcp'){
  let body='';req.on('data',c=>body+=c);req.on('end',()=>{
   let msg;try{msg=JSON.parse(body)}catch{return send(res,400,{error:'Invalid JSON'})}
   const id=msg.id??null; const method=msg.method;
   if(method==='initialize') return send(res,200,rpcResult(id,{protocolVersion:'2024-11-05',capabilities:{tools:{},resources:{}},serverInfo:{name:'cinek-artist-universe',version:'0.1.0'}}));
   if(method==='notifications/initialized') return send(res,202,'','text/plain');
   if(method==='ping') return send(res,200,rpcResult(id,{}));
   if(method==='tools/list') return send(res,200,rpcResult(id,{tools}));
   if(method==='resources/list') return send(res,200,rpcResult(id,{resources:[{uri:'cinek://catalog',name:'Cinek catalogue',mimeType:'application/json'}]}));
   if(method==='resources/read') return send(res,200,rpcResult(id,{contents:[{uri:'cinek://catalog',mimeType:'application/json',text:JSON.stringify(catalog)}]}));
   if(method==='tools/call'){
    const name=msg.params?.name, args=msg.params?.arguments||{};let result;
    if(name==='get_artist') result=catalog.artist;
    else if(name==='list_songs') result=catalog.songs;
    else if(name==='list_links') result=catalog.socials;
    else if(name==='list_wiki') result=catalog.wiki;
    else if(name==='search_catalog'){const q=String(args.query||'').toLowerCase();result={songs:catalog.songs.filter(x=>x.title.toLowerCase().includes(q)),wiki:catalog.wiki.filter(x=>(x.title+' '+x.summary).toLowerCase().includes(q))};}
    else return send(res,200,rpcResult(id,{isError:true,content:[{type:'text',text:'Unknown tool'}]}));
    return send(res,200,rpcResult(id,{content:[{type:'text',text:JSON.stringify(result)}]}));
   }
   return send(res,200,{jsonrpc:'2.0',id,error:{code:-32601,message:'Method not found'}});
  });return;
 }
 let filePath=path.join(root,decodeURIComponent(url.pathname));
 if(url.pathname.endsWith('/')) filePath=path.join(filePath,'index.html');
 if(!filePath.startsWith(root)) return send(res,403,{error:'Forbidden'});
 fs.readFile(filePath,(err,data)=>{if(err)return send(res,404,'Not found','text/plain');send(res,200,data,mime[path.extname(filePath)]||'application/octet-stream')});
});
const port=process.env.PORT||3000;server.listen(port,()=>console.log(`Cinek site listening on ${port}`));
